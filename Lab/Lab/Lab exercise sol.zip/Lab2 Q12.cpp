#include <iostream>
using namespace std;

int main(){
    char letter[5] = {};

    for (int i=0; i<5;i++){
        cout<<"Enter a character";
        cin>>letter[i];
        if (letter[i] == 'n')
        break;
    }
    for (j=0; j<)

    return 0;
}