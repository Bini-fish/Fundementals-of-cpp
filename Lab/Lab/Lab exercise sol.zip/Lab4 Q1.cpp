#include <iostream>
using namespace std;

void fun();

int main(){
    fun();
    return 0;
}

void fun(){
    cout<<"Hello World!"<<endl;
}