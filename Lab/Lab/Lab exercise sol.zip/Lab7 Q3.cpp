#include <iostream>
using namespace std;

struct Date{
    int day;
    int month;
    int year;
}
int main(){
    Date a,b;
    cout<<"Enter the first date: ";
    cin>>a.day
    cout<<"Enter the first month: ";
    cin>>a.month
    cout<<"Enter the first year: ";
    cin>>a.year
    cout<<"Enter the Second date: ";
    cin>>a.day
    cout<<"Enter the Second month: ";
    cin>>a.month
    cout<<"Enter the Second year: ";
    cin>>a.year

    
    return 0;
}